# Terraform: Databricks auth via Vault KV v2 (Pattern 1)

## What this does
- Reads `client_id`, `client_secret` (and optionally `account_id`) from Vault KV v2
- Configures the Databricks Terraform provider with those values
- Runs a simple `databricks_current_user` data source to validate auth

## Vault secret format (KV v2)
Path (example): `secret/databricks/spn`
Keys:
- `client_id`
- `client_secret`
- `account_id` (optional)

Example Vault CLI:
```bash
vault kv put secret/databricks/spn \
  client_id="xxxx" \
  client_secret="yyyy" \
  account_id="zzzz"
```

## Run (no secrets in tfvars)
1) Copy example tfvars:
```bash
cp terraform.tfvars.example terraform.tfvars
```

2) Export a short-lived Vault token (do NOT commit it):
```bash
export VAULT_TOKEN="s.xxxxx"
```

3) Init/plan/apply:
```bash
terraform init
terraform plan
terraform apply
```

## Notes
- Keep Terraform state secure (remote state + encryption recommended).
- Do not create Terraform outputs for secret values.
